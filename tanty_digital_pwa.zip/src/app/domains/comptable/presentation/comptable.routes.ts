import { Routes } from '@angular/router';
import { ComptableLayoutComponent } from '../../../layout/comptable-layout/comptable-layout.component';

export const COMPTABLE_ROUTES: Routes = [
  {
    path: '',
    component: ComptableLayoutComponent,
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard', loadComponent: () => import('./pages/dashboard/comptable-dashboard.component').then(m => m.ComptableDashboardComponent) },
      { path: 'commandes', loadComponent: () => import('./pages/commandes/comptable-commandes.component').then(m => m.ComptableCommandesComponent) },
      { path: 'factures', loadComponent: () => import('./pages/factures/comptable-factures.component').then(m => m.ComptableFacturesComponent) },
      { path: 'caisse', loadComponent: () => import('./pages/caisse/comptable-caisse.component').then(m => m.ComptableCaisseComponent) },
      { path: 'recouvrement', loadComponent: () => import('./pages/recouvrement/comptable-recouvrement.component').then(m => m.ComptableRecouvrementComponent) },
      { path: 'reporting', loadComponent: () => import('./pages/reporting/comptable-reporting.component').then(m => m.ComptableReportingComponent) },
      { path: 'objectifs', loadComponent: () => import('./pages/objectifs/comptable-objectifs.component').then(m => m.ComptableObjectifsComponent) },
      { path: 'primes', loadComponent: () => import('./pages/primes/comptable-primes.component').then(m => m.ComptablePrimesComponent) },
      { path: 'rapports', loadComponent: () => import('./pages/rapports/comptable-rapports.component').then(m => m.ComptableRapportsComponent) },
      // Dernière étape du cycle de fin de tournée, après le rapprochement secrétaire.
      { path: 'sessions', loadComponent: () => import('./pages/sessions/comptable-sessions.component').then(m => m.ComptableSessionsComponent) },
      // Le découpage territorial conditionne les objectifs qu'il fixe : il
      // l'administre au même titre que la Chargée RP.
      { path: 'zones', loadComponent: () => import('../../commercial/presentation/pages/zones-admin/zones-admin.component').then(m => m.ZonesAdminComponent) },
      // Commandes clients hors tournée (téléphone, WhatsApp, SMS, email) — écran
      // partagé (voir shared/commande-client).
      { path: 'commandes-clients', loadComponent: () => import('../../../shared/commande-client/commande-client.component').then(m => m.CommandeClientComponent) },
      // Moteur de validation générique, réutilisé sans quitter la coquille Comptable (même
      // correction que DG/Contrôle, 2026-10-16) : le sidebar pointait vers /validations,
      // route de premier niveau sans aucun layout.
      { path: 'validations', loadComponent: () => import('../../../shared/validation-pending/validation-pending.component').then(m => m.ValidationPendingComponent) },
    ]
  }
];
